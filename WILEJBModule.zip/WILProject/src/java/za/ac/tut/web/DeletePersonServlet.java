/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.ejb.bl.DocumentsFacadeLocal;
import za.ac.tut.ejb.bl.SkillsFacadeLocal;
import za.ac.tut.ejb.bl.UserDetailsEntityFacadeLocal;
import za.ac.tut.ejb.entities.Documents;
import za.ac.tut.ejb.entities.Skills;
import za.ac.tut.ejb.entities.UserDetailsEntity;

/**
 *
 * @author Malthus Lidavhu
 */
public class DeletePersonServlet extends HttpServlet {
    @EJB
    private SkillsFacadeLocal sfl;
    @EJB
    private DocumentsFacadeLocal dfl;
    @EJB
    private UserDetailsEntityFacadeLocal udefl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        Long id = Long.parseLong(request.getParameter("skill_id"));
        
        UserDetailsEntity person = new UserDetailsEntity();
        Documents docs = new Documents();
        docs.setPerson(person);
        person.setId(id);
        Skills skill = new Skills();
        skill.setPerson(person);
        
        sfl.remove(skill);
        
        dfl.remove(docs);
        
        RequestDispatcher disp = request.getRequestDispatcher("deleteoutcome.jsp");
        disp.forward(request, response);
        
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.ejb.bl.SkillsFacadeLocal;
import za.ac.tut.ejb.entities.Skills;

/**
 *
 * @author Malthus Lidavhu
 */
public class SearchBySkillServlet extends HttpServlet {

    @EJB
    private SkillsFacadeLocal sfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String skill = request.getParameter("skill");
        
        List<Skills> findBySkill = sfl.findBySkill(skill);
        session.setAttribute("findBySkill", findBySkill);
        
        RequestDispatcher disp = request.getRequestDispatcher("viewjobseekersbyskill.jsp");
        disp.forward(request, response);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.ejb.bl.SkillsFacadeLocal;
import za.ac.tut.ejb.entities.Skills;
import za.ac.tut.ejb.entities.UserDetailsEntity;

/**
 *
 * @author Malthus Lidavhu
 */
public class SkillsServlet extends HttpServlet {
    @EJB
    private SkillsFacadeLocal sfl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        
        UserDetailsEntity person = (UserDetailsEntity) session.getAttribute("person");
        
        Skills skills = new Skills();
        String skill1 = request.getParameter("skill1");
        String skill2 = request.getParameter("skill2");
        String skill3 = request.getParameter("skill3");
        String skill4 = request.getParameter("skill4");
        String skill5 = request.getParameter("skill5");
        skills = createSkills(person,skill1,skill2,skill3,skill4,skill5);
        
        sfl.create(skills);
        
        RequestDispatcher disp = request.getRequestDispatcher("skillsadded.jsp");
        disp.forward(request, response);
    }

    private Skills createSkills(UserDetailsEntity person,String skill1,String skill2,String skill3,String skill4,String skill5) {
        Skills skills = new Skills();
        skills.setPerson(person);
        skills.setSkill1(skill1);
        skills.setSkill2(skill2);
        skills.setSkill3(skill3);
        skills.setSkill4(skill4);
        skills.setSkill4(skill4);
        skills.setSkill5(skill5);
        return skills;
    }

  
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.ejb.entities.Skills;

/**
 *
 * @author Malthus Lidavhu
 */
@Stateless
public class SkillsFacade extends AbstractFacade<Skills> implements SkillsFacadeLocal {

    @PersistenceContext(unitName = "WILEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SkillsFacade() {
        super(Skills.class);
    }

    @Override
    public List<Skills> findByAgeRange(Integer min_age, Integer max_age) {
        Query query = em.createQuery("SELECT s FROM Skills s WHERE s.person.age >= :min_age AND s.person.age <= :max_age ORDER BY s.person.age");
        query.setParameter("min_age", min_age);
        query.setParameter("max_age", max_age);
        List<Skills> resultList = (List<Skills>)query.getResultList();
        return resultList;
    }

    @Override
    public List<Skills> findBySkill(String skill) {
        Query query = em.createQuery("SELECT s FROM Skills s WHERE s.skill1 LIKE :skill OR s.skill2 LIKE :skill OR s.skill3 LIKE :skill OR s.skill4 LIKE :skill OR s.skill5 LIKE :skill");
        query.setParameter("skill", "%" + skill + "%");
        
        List<Skills> resultList = (List<Skills>)query.getResultList();
        return resultList;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.ejb.entities.Skills;

/**
 *
 * @author Malthus Lidavhu
 */
@Local
public interface SkillsFacadeLocal {

    void create(Skills skills);

    void edit(Skills skills);

    void remove(Skills skills);

    Skills find(Object id);

    List<Skills> findAll();
    
    List<Skills> findByAgeRange(Integer min_age,Integer max_age);
    
    List<Skills> findBySkill(String skill);

    List<Skills> findRange(int[] range);

    int count();
    
}

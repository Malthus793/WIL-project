/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.ejb.entities.UserDetailsEntity;

/**
 *
 * @author Malthus Lidavhu
 */
@Stateless
public class UserDetailsEntityFacade extends AbstractFacade<UserDetailsEntity> implements UserDetailsEntityFacadeLocal {

    @PersistenceContext(unitName = "WILEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UserDetailsEntityFacade() {
        super(UserDetailsEntity.class);
    }

    @Override
    public UserDetailsEntity find(String email) {
        Query query = em.createQuery("SELECT u FROM UserDetailsEntity u WHERE u.email = :email");
        query.setParameter("email", email);
        UserDetailsEntity ude = (UserDetailsEntity)query.getSingleResult();
        return ude;
    }
    
}

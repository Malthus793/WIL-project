/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author Malthus Lidavhu
 */
@Entity
public class Documents implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @ManyToOne
    private UserDetailsEntity person;
    private String cv;
    private String supportingdocuments;
    private String qualifications;
    private String idcopy;

    public Documents() {
    }

    public Documents(Long id, UserDetailsEntity person, String cv, String supportingdocuments, String qualifications, String idcopy) {
        this.id = id;
        this.person = person;
        this.cv = cv;
        this.supportingdocuments = supportingdocuments;
        this.qualifications = qualifications;
        this.idcopy = idcopy;
    }

    public UserDetailsEntity getPerson() {
        return person;
    }

    public void setPerson(UserDetailsEntity person) {
        this.person = person;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }

    public String getSupportingdocuments() {
        return supportingdocuments;
    }

    public void setSupportingdocuments(String supportingdocuments) {
        this.supportingdocuments = supportingdocuments;
    }

    public String getQualifications() {
        return qualifications;
    }

    public void setQualifications(String qualifications) {
        this.qualifications = qualifications;
    }

    public String getIdcopy() {
        return idcopy;
    }

    public void setIdcopy(String idcopy) {
        this.idcopy = idcopy;
    }
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Documents)) {
            return false;
        }
        Documents other = (Documents) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "za.ac.tut.ejb.entities.Documents[ id=" + id + " ]";
    }
    
}
